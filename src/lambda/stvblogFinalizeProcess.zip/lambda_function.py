# ==================================================================================
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# ==================================================================================
#
# stvblogPrepareProcess
# by: Rob Dachowski
# For questions or feedback, please contact robdac@amazon.com
#
# Purpose: The labmda does the initial setup for running the process
#
# Change Log:
#           3/1/21: Initial version
#
# ==================================================================================

import json
import uuid
import boto3
from botocore.exceptions import ClientError
import ssmparms as sp
import stmparms as stm
import stverrors

# ==================================================================================
# Function:lambda_handler
# Purpose: This is the main function for this lambda.  I
# Parameters:
#	event - the input json structure
#	context - lambda context
# ==================================================================================

def lambda_handler(event, context):
	print("===> stvblogCombinePhrasesAndTranslation: " + "\nEvent:" + str(event))
	print("\t---> Boto Version: ", boto3.__version__)

	# Load the parms from DynamoDB
	parms = stm.get_stm_parms(event['Outputs']['process']['ProcessName'])

	if not parms:
		# We have an issue, so get out
		raise stvDynamoDBError("*** Unable to load parms from DynamoDB ***")

	po = parms['Item']['Outputs']
	response = event

	print( "po: ", po )

	# If we got here, we are done, so mark the status as completed
	if po['mediaConvert']['mediaConvertJobStatus'] == 'COMPLETE':
		print( "Complete")
		response['Outputs']['process']['status'] = "COMPLETED"
	else:
		response['Outputs']['process']['status'] = "ERROR"

	if stm.update_stm_parms(response['Outputs']['process']['ProcessName'], response['Config'], response['Inputs'], response['Outputs'], event['Targets']):
		print('===>stvblogCFinalizeProcess Complete')
		return response
	else:
		raise stvError("*** Error writing to the stvblog table ***")

