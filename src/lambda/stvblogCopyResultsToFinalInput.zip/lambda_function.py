# ==================================================================================
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# ==================================================================================
#
# stvblogCopyResultsToFinalInput.py
# by: Rob Dachowski
# For questions or feedback, please contact robdac@amazon.com
#
# Purpose: This code copies all of the resulting files to the FinalInput folder for use by Elemental
#
# Change Log:
#          3/1/2021: Initial version
#
# ==================================================================================



import json
import uuid
from datetime import datetime
import boto3
from botocore.exceptions import ClientError
import ssmparms as sp
import stmparms as stm
import stverrors


# ==================================================================================
# Function: labmda_handler
# Purpose: This is the "main" code for this lambda function
# Parameters:
#                 event - the JSON input structure containing the parameters from the step function process
# ==================================================================================

def lambda_handler(event, context):

	#debugging message
	print("===> CopyResultsToFinalInput: " + "\nEvent:" + str(event) + "\nContext: " + str( event['index'] ) )
	print( "\t---> Boto Version: ", boto3.__version__ )

	# Load the parms from DynamoDB
	parms = stm.get_stm_parms( event['input']['Outputs']['process']['ProcessName'])

	if not parms:
		# We have an issue, so get out
		raise stvDynamoDBError( "*** Unable to load parms from DynamoDB ***")

	# set up a shortcut
	pc = parms['Item']['Config']
	pi = parms['Item']['Inputs']
	po = parms['Item']['Outputs']
	ptgts = parms['Item']['Targets']
	pt = event['item']['translate']
	sls = pi['sourceLanguageShort']
	slf = pi['sourceLanguageFull']
	tls = event['item']['translate']['targetLanguageShort']
	tlf = event['item']['translate']['targetLanguageFull']
	
	s3 = boto3.resource('s3')
	response = event
	
    # Copy the Subtitles to the FinalInput folder
	if event['item']['subtitle']['createSubtitle'] == 'y':
		source = {"Bucket": pc['baseBucketName'], "Key": event['item']['subtitle']['srtKey'] }
		destination = s3.Bucket( pc['baseBucketName'] )
		destinationKey = po['process']['uuid'] + '/' + pc['finalInput'] + '/' + pi['mediaFile'] + '.' + event['item']['translate']['targetLanguageShort'] + ".srt"
		print( "\t---> Copying ", str(source), " to ", str(destination) + "/" + destinationKey)
		destination.copy( source, destinationKey)
		s3Uri = "s3://" + pc['baseBucketName'] + '/' + destinationKey
		print( "\t---> s3Uri is: ", s3Uri)
		event['item']['subtitle']['subtitleUri'] = s3Uri
		event['input']['Targets'][event['index']]['subtitle']['subtitleUri'] = s3Uri
		ptgts[event['index']]['subtitle']['subtitleUri'] = s3Uri

    # Copy the polly generated MP3 to the FinalInput folder
	if  event['item']['polly']['createAudio'] == 'y':
		source = {"Bucket": pc['baseBucketName'], "Key":  event['item']['polly']['pollyOutputKey']  }
		destination = s3.Bucket( pc['baseBucketName'] )
		destinationKey = po['process']['uuid'] + '/' + pc['finalInput'] + '/' + pi['mediaFile'] + '.' + event['item']['translate']['targetLanguageShort'] + ".mp3"
		print( "\t---> Copying ", str(source), " to ", str(destination) + "/" + destinationKey)
		destination.copy( source, destinationKey)
		pollyUri = "s3://" + pc['baseBucketName'] + '/' + destinationKey
		event['item']['polly']['pollyUri'] = pollyUri
		event['input']['Targets'][event['index']]['polly']['pollyUri'] = pollyUri
		ptgts[event['index']]['polly']['pollyUri'] = pollyUri
	


	# Put the ouptut back into DynamoDB
	#if stm.update_stm_parms( event['input']['Outputs']['process']['ProcessName'], event['input']['Config'], event['input']['Inputs'],event['input']['Outputs'], event['input']['Targets'] ):
	if stm.update_stm_target( event['input']['Outputs']['process']['ProcessName'], ptgts[event['index']], event['index'] ):
		print('===> CopyResultsToFinalInput Complete')
		return response
	else:
		raise stvError( "*** Error writing to the stvblog table ***" )
