# ==================================================================================
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# ==================================================================================
#
# stvblogTranscribeMedia
# by: Rob Dachowski
# For questions or feedback, please contact robdac@amazon.com
# 
# Purpose: The labmda creates an AWS Transcribe job, updates the result path and returns.  It is part of a step function process
#
# Change Log:
#           3/1/21: Initial version
#
# ==================================================================================

import json
import uuid
import datetime
import boto3
from botocore.exceptions import ClientError
import ssmparms as sp
import stmparms as stm
import stverrors




# ==================================================================================
# Function: labmda_handler
# Purpose: This is the "main" code for this lambda function
# Parameters: 
#                 event - the JSON input structure containing the parameters from the step function process
# ==================================================================================

def lambda_handler(event, context):

	#debugging message
	print("===> stvblogTranscribeMedia: " + "\nEvent:" + str(event) )
	print( "Boto Version: ", boto3.__version__ )
	
	# Load the parms from DynamoDB	
	parms = stm.get_stm_parms( event['Outputs']['process']['ProcessName'])
	
	if not parms:
		# We have an issue, so get out
		raise stvDynamoDBError( "*** Unable to load parms from DynamoDB ***")
	
	# set up a shortcut	
	pc = parms['Item']['Config']
	pi = parms['Item']['Inputs']
	po = parms['Item']['Outputs']
	
	# Set up Transcribe
	transcribe = boto3.client('transcribe')

	# Set up the job name
	jobName = "transcribe_" + po['process']['uuid']
	
	# Set up the OutputKey with the format uuid/transcribeOutput/jobName.json
	OutputKey = po['process']['uuid'] + '/' + pc['transcriptionOutput'] + '/' + jobName + ".json"

	print( "\t---> Creating Job: " + jobName + " for " + pi['mediaURI'] )
	
	
	try:
		
		# Call Transcribe to start the job.
		r = transcribe.start_transcription_job(
			TranscriptionJobName = jobName,
			LanguageCode = pi['sourceLanguageFull'],
			MediaFormat=pi['mediaFormat'],
			Media = {"MediaFileUri": pi['mediaURI']},
			OutputBucketName=pc['baseBucketName'],
			OutputKey=OutputKey
			)
	except ClientError as e:
		print("*** Error reading creating Transcribe Job ***")
		raise stvError("*** Error Code: ", e.response['Error']['Message'] + " ***")
	
	
	print( "\t--->Transcribe Job Submitted: ", r['TranscriptionJob']['TranscriptionJobName'] )
	
	
	# set up the transcribeJobOutput path in the JSON file.  The path is defined in the Step Function
	response = {}
	response['Config'] = parms['Item']['Config']
	response['Inputs'] = parms['Item']['Inputs']
	response['Outputs'] = parms['Item']['Outputs']
	response['Outputs']['transcribe'] = {}
	response['Outputs']['transcribe']['transcribeJobName'] = r['TranscriptionJob']['TranscriptionJobName']
	response['Outputs']['transcribe']['transcriptionKey'] = OutputKey
	response['Outputs']['transcribe']['transcribeJobStatus'] = r['TranscriptionJob']['TranscriptionJobStatus']
	response['Outputs']['transcribe']['startTimeStamp'] = r['TranscriptionJob']['CreationTime'].strftime("%Y-%m-%d %H-%M-%S")
	
	response['Targets'] = parms['Item']['Targets']
	
	# Put the ouptut back into DynamoDB
	if stm.update_stm_parms( response['Outputs']['process']['ProcessName'], response['Config'], response['Inputs'],response['Outputs'], event['Targets'] ):
		print('===>stvblogTranscribeMedia Complete')
		return response
	else:
		raise stvError( "*** Error writing to the stvblog table ***" )