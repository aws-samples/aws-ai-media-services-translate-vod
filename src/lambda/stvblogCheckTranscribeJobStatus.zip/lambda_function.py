# ==================================================================================
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# ==================================================================================
#
# stvblogCheckTranscribeJobStatus
# by: Rob Dachowski
# For questions or feedback, please contact robdac@amazon.com
# 
# Purpose: The labmda checks on the status of the Transcribe Job and sets the status in DynamoDB
#
# Change Log:
#           3/1/21: Initial version
#
# ==================================================================================

import json
import boto3
from botocore.exceptions import ClientError
import datetime
import ssmparms as sp
import stmparms as stm
import stverrors

# ==================================================================================
# Function:lambda_handler
# Purpose: This is the main function for this lambda.  I
# Parameters: 
#	event - the input json structure
#	context - lambda context				
# ==================================================================================	


def lambda_handler(event, context):
	
	# debugging message
	print("===> stvblogCheckTranscribeJobStatus: " + "\nEvent:" + str(event) )
	print( "Boto Version: ", boto3.__version__ )
	
	# Load the parms from DynamoDB	
	parms = stm.get_stm_parms( event['Outputs']['process']['ProcessName'])
	
	if not parms:
		# We have an issue, so get out
		raise stvDynamoDBError( "*** Unable to load parms from DynamoDB ***")
	
	# set up a shortcut	
	pc = parms['Item']['Config']
	pi = parms['Item']['Inputs']
	po = parms['Item']['Outputs']
	
	#pull the jobName from the event JSON and check the status
	transcribe = boto3.client('transcribe')
	
	try:
		# Check on the Transcribe Job
		print( po )
		print( "\t---> Checking on status of Transcribe Job: ", po['transcribe']['transcribeJobName'])
		status = transcribe.get_transcription_job( TranscriptionJobName=po['transcribe']['transcribeJobName'] )
	except ClientError as e:
		print("*** Error reading Checking on the Transcribe Job ", po['transcribe']['transcribeJobName'] + " ***")
		raise stvError("*** Error Code: ", e.response['Error']['Message'] + " ***")
		
	print( "\t---> Status of Transcribe Job: ", status['TranscriptionJob']['TranscriptionJobStatus'])	
	
	# Set up the response
	response = event

	response['Outputs']['transcribe']['transcribeJobStatus'] = status['TranscriptionJob']['TranscriptionJobStatus']
	response['Outputs']['transcribe']['startTimeStamp'] = datetime.datetime.now().strftime("%Y-%m-%d %H-%M-%S")

	# Now update the status
	if status['TranscriptionJob']['TranscriptionJobStatus'] == 'COMPLETED':
		response['Outputs']['transcribe']['transcriptURI'] = status['TranscriptionJob']['Transcript']['TranscriptFileUri']
		response['Outputs']['transcribe']['completionTime'] = status['TranscriptionJob']['CompletionTime'].strftime("%Y-%m-%d %H-%M-%S")
	else:
		response['Outputs']['transcribe']['transcribeJobStatus'] = status['TranscriptionJob']['TranscriptionJobStatus']

	# Put the ouptut back into DynamoDB
	if stm.update_stm_parms( response['Outputs']['process']['ProcessName'], response['Config'], response['Inputs'],response['Outputs'], event['Targets'] ):
		print('===>stvblogCheckTranscribeJobStatus Complete')
		return response
	else:
		raise stvError( "*** Error writing to the stvblog table ***" )
