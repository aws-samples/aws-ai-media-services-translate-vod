# ==================================================================================
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# ==================================================================================
#
# stvblogGetJobList
# by: Matthew Juliana
# For questions or feedback, please contact mattjul@amazon.com
# 
# Purpose: The labmda queries the dynamodb table to get a list of the subtitle/translate jobs 
# along with their status.
# 
# Change Log:
#           3/1/21: Initial version
#
# ==================================================================================


import json
import boto3
import botocore
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    
    # set up Dynamo DB
    dd = boto3.resource('dynamodb')
    table = dd.Table("stvblog")
    
    data = []
    
    # response = table.scan(FilterExpression="attribute_exists(Outputs.process.videoPlaybackUrl)")
    response = table.scan()
    items = response['Items']
    for item in items:
        jobId = item['Outputs']['process']['uuid']
        jobStatus = item['Outputs']['process']['status']
        fileName = item['Inputs']['mediaFile']
        try:
            playbackUrl = item['Outputs']['process']['videoPlaybackUrl']
        except KeyError:
            playbackUrl = ''

        data.append({'jobId': jobId, 'jobStatus': jobStatus, 'fileName': fileName, 'playbackUrl': playbackUrl})
        

    while 'LastEvaluatedKey' in response:
        key = response['LastEvaluatedKey']
        
        response = table.scan(FilterExpression="attribute_exists(Outputs.process.videoPlaybackUrl)",ExclusiveStartKey=key)
        items = response['Items']
        for item in items:
            jobId = item['Outputs']['process']['uuid']
            jobStatus = item['Outputs']['process']['status']
            fileName = item['Inputs']['mediaFile']
            try:
                playbackUrl = item['Outputs']['process']['videoPlaybackUrl']
            except KeyError:
                playbackUrl = ''

            data.append({'jobId': jobId, 'jobStatus': jobStatus, 'fileName': fileName, 'playbackUrl': playbackUrl})            

    data = {'data':data}
    json_str = json.dumps(data)
    print(json_str)

    # # TODO implement
    return {
        'statusCode': 200,
        'body': json_str
        
    }
