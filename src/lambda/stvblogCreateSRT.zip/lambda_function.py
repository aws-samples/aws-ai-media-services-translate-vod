# ==================================================================================
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# ==================================================================================
#
# CreateSRT
# by: Rob Dachowski
# For questions or feedback, please contact robdac@amazon.com
# 
# Purpose: This lambda creates a language specific SRT file
#
# Change Log:
#           01/15/21: Initial version
#
# ==================================================================================

import json
import uuid
import datetime
import boto3
from botocore.exceptions import ClientError
import ssmparms as sp
import stmparms as stm
import stverrors


# ==================================================================================
# Function: labmda_handler
# Purpose: This is the "main" code for this lambda function
# Parameters: 
#                 event - the JSON input structure containing the parameters from the step function process
# ==================================================================================

def lambda_handler(event, context):

	#debugging message
	print("===> CreateSRT: " + "\nEvent:" + str(event) + "\nContext: " + str( context ) )
	print( "\t---> Boto Version: ", boto3.__version__ )
	
	# Load the parms from DynamoDB	
	parms = stm.get_stm_parms( event['input']['Outputs']['process']['ProcessName'])
	
	if not parms:
		# We have an issue, so get out
		raise stvDynamoDBError( "*** Unable to load parms from DynamoDB ***")
	
	# set up a shortcut	
	pc = parms['Item']['Config']
	pi = parms['Item']['Inputs']
	po = parms['Item']['Outputs']
	ptgts = parms['Item']['Targets']
	pt = event['item']['translate']
	sls = pi['sourceLanguageShort']
	slf = pi['sourceLanguageFull']
	tls = event['item']['translate']['targetLanguageShort']
	tlf = event['item']['translate']['targetLanguageFull']

	#set up AWS resource for S3
	s3 = boto3.resource( 's3')   
	bucket = s3.Bucket(pc['baseBucketName'])

	combinedPhrasesKey = event['item']['subtitle']['combinedPhrasesKey']

	try:
		# Get the phrases file from S3 and read it into memory
		phraseFile = bucket.Object( key=combinedPhrasesKey )
		phraseResponse = phraseFile.get()
	except Exception as e:
		print( "***Exception***: Issue reading phrase file: ", combinedPhrasesKey)
		raise stvError("*** Error Code: ", e.response['Error']['Message'] + " ***")

	# Get the bytes from the "body" section
	phrasesIn = phraseResponse['Body'].read()
	phrasesIn = json.loads(phrasesIn.decode('utf-8'))

	srtOut = ""
	x = 1

	for phrase in phrasesIn:

		# determine how many words are in the phrase
		# length = len(phrase["words"])
		
		# write out the phrase number
		srtOut += str(x) + "\n"
		x += 1
		
		# write out the start and end time
		srtOut += phrase["timecode"] + "\n" 
					
		# write out the full phase.  Use spacing if it is a word, or punctuation without spacing
		srtOut += phrase['words'] + "\n\n" 


	# Create the key for the SRT  file
	srtKey = po['process']['uuid'] + '/' + pc['subtitleOutput'] + '/' + pi['mediaFile'] + "." + tls + '.srt'
	
	# put the new S3 object
	try:
		bucket.put_object(Body=srtOut, ContentType="text/plain", Key=srtKey )
	except Exception as e:
		print( "***Exception***: Issue writing SRT file: ", srtKey)
		raise stvError("*** Error Code: ", e.response['Error']['Message'] + " ***")

    	# Generate and return the repsonse 
	response = event
	response['item']['subtitle']['srtKey'] = srtKey
	ptgts[event['index']]['subtitle']['srtKey'] = srtKey

	
	# Put the ouptut back into DynamoDB
	if stm.update_stm_target( event['input']['Outputs']['process']['ProcessName'], ptgts[event['index']], event['index'] ):
		print('===> stvblogCreateSRT Complete')
		return response
	else:
		raise stvError( "*** Error writing to the stvblog table ***" )
