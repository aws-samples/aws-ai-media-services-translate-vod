
# ==================================================================================
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# ==================================================================================
#
# stvblogGetUploadUrl
# by: Matthew Juliana
# For questions or feedback, please contact mattjul@amazon.com
# 
# Purpose: The labmda will generate a pre-signed URL for uploading the source video file
# 
# Change Log:
#           3/1/21: Initial version
#
# ==================================================================================


import json
import boto3
from botocore.exceptions import ClientError
import ssmparms as sp

def lambda_handler(event, context):
    
    uploadBucketName = sp.get_parameter( "/stvblog/uploadFolder")['Parameter']['Value']
    fileName=event["queryStringParameters"]['filename']
    objectName=fileName
    fields = {"Content-Type": "video/mp4"}
    conditions = [
    {"Content-Type": "video/mp4"}
    ]
    expiration=300


    # # Generate a presigned S3 POST URL
    s3_client = boto3.client('s3')
    try:
        response = s3_client.generate_presigned_post(uploadBucketName, objectName, Fields=fields, Conditions=conditions, ExpiresIn=expiration)
    except ClientError as e:
        print(e)
        return None
    
    return response