# ==================================================================================
# Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.

# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# ==================================================================================
#
# stmparms
# by: Rob Dachowski
# For questions or feedback, please contact robdac@amazon.com
# 
# Purpose: Utility functions for reading/writin from DynamoDB 
#
# Change Log:
#           10/26/20: Initial version
#
# ==================================================================================

import boto3
from botocore.exceptions import ClientError
import stverrors

def get_stm_parms( ProcessName ):
	
	returnVal = None

	print( '\t---> Getting Config, Input, Output, and Targets in DynamoDB' )

	# We need a ProcessName key to look up in DD
	if not ProcessName:
		raise stvDynamoDBError( '\t---> get_stm_parms error: invalid ProcessName' )
		return returnVal

	# set up Dynamo DB
	dd = boto3.resource('dynamodb')
	table = dd.Table("stvblog")

	# Get the parameters in DynamoDB which should include the ProcessName, Config, input, Output, and Targets	
	try:
		response = table.get_item(Key={'ProcessName': ProcessName } )
	except ClientError as e:
		print("*** Error reading DynamoDB for ProcessName: ", ProcessName + " ***")
		raise stvDynamoDBError( e )
		return returnVal
	
	returnVal = response

	return returnVal


def put_new_stm_parms(ProcessName, Config, Inputs, Outputs, Targets ):

	returnVal = None

	# We need a ProcessName key to look up in DD
	if not ProcessName:
		raise stvDynamoDBError( '\t--->put_new_stm_parms error: invalid ProcessName' )
		return returnVal
		
	# set up Dynamo DB
	dd = boto3.resource('dynamodb')
	table = dd.Table("stvblog")

	# Get the parameters in DynamoDB which should include the ProcessName, Config, input, Output, and Targets	
	print( '\t---> Adding new Config, Inputs, Outputs, and Targets in DynamoDB' )
	try:
		r = table.put_item( 
			Item=
			{
				'ProcessName': ProcessName,
				'Config': Config,
				'Inputs': Inputs, 
				'Outputs': Outputs,
				'Targets': Targets
			} 
			)
	except ClientError as e:
		print("*** Error writing to DynamoDB for ProcessName: ", ProcessName + " ***")
		raise stvDynamoDBError( e )
		return False
	else:
		print( '\t---> DynamoDB successfully updated: ', r )
		return True
		

def update_stm_parms(ProcessName, Config, Inputs, Outputs, Targets ):

	returnVal = None

	# We need a ProcessName key to look up in DD
	if not ProcessName:
		raise stvDynamoDBError( '\t--->put_new_stm_parms error: invalid ProcessName' )
		return returnVal

	# set up Dynamo DB
	dd = boto3.resource('dynamodb')
	table = dd.Table("stvblog")

	# Get the parameters in DynamoDB which should include the ProcessName, Config, input, Output, and Targets	
	print( '\t--->Updating Config, Inputs, Outputs, and Targets in DynamoDB' )
	try:
		response = table.update_item(
			Key={
				'ProcessName': ProcessName
			},
			UpdateExpression="set Config=:cfg, Inputs=:in, Outputs=:out, Targets=:tgt",
			ExpressionAttributeValues=
			{
				':cfg': Config,
				':in': Inputs,
				':out': Outputs,
				':tgt': Targets	
			},
			ReturnValues="UPDATED_NEW"
			)
	except ClientError as e:
		print("*** Error updating DynamoDB for ProcessName: ", ProcessName + " ***")
		raise stvDynamoDBError( e )
		return returnVal
	else:
		print( '\t--->DynamoDB successfully updated: ', response )
		return response


def update_stm_target(ProcessName, Target, Index ):

	returnVal = None

	# We need a ProcessName key to look up in DD
	if not ProcessName:
		raise stvDynamoDBError( '\t--->put_new_stm_target error: invalid ProcessName' )
		return returnVal
		
	print( "Index: ", Index)

	# set up Dynamo DB
	dd = boto3.resource('dynamodb')
	table = dd.Table("stvblog")

	# Get the parameters in DynamoDB which should include the ProcessName, Config, input, Output, and Targets	
	print( '\t--->Updating Target %d in DynamoDB for %s' % (Index, ProcessName) )
	try:
		response = table.update_item(
			Key={
				'ProcessName': ProcessName
			},
			UpdateExpression='set Targets[' + str(Index) + "]=:tgt",
			ExpressionAttributeValues=
			{
				':tgt': Target
			},
			ReturnValues="UPDATED_NEW"
			)
	except ClientError as e:
		print("*** Error updating DynamoDB for ProcessName: ", ProcessName + " ***")
		raise stvDynamoDBError( e )
		return returnVal
	else:
		print( '\t--->DynamoDB successfully updated: ', response )
		return response
