# ==================================================================================
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
# http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
# ==================================================================================
#
# ssmparms.py
# by: Rob Dachowski
# For questions or feedback, please contact robdac@amazon.com
# 
# Purpose: Borrowed from the Utility functions for reading/writing parms stored in Systems Manager's Parameter Store
#
# Change Log:
#           3/1/21: Initial version
#
# ==================================================================================


import boto3
from botocore.exceptions import ClientError
import stverrors


def put_parameter(parameter_name, parameter_value, parameter_type="String"):
    """Creates new parameter in AWS SSM

    :param parameter_name: Name of the parameter to create in AWS SSM
    :param parameter_value: Value of the parameter to create in AWS SSM
    :param parameter_type: Type of the parameter to create in AWS SSM ('String'|'StringList'|'SecureString')
    :return: Return version of the parameter if successfully created else None
    """
    ssm_client = boto3.client('ssm')

    try:
        result = ssm_client.put_parameter(
            Name=parameter_name,
            Value=parameter_value,
            Type=parameter_type
        )
    except ClientError as e:
        raise stvParameterStoreError( e )
        return None
    return result['Version']


def put_parameter_with_overwrite(parameter_name, parameter_value, parameter_type="String"):
    """Creates new parameter in AWS SSM

    :param parameter_name: Name of the parameter to create in AWS SSM
    :param parameter_value: Value of the parameter to create in AWS SSM
    :param parameter_type: Type of the parameter to create in AWS SSM ('String'|'StringList'|'SecureString')
    :return: Return version of the parameter if successfully created else None
    """
    ssm_client = boto3.client('ssm')

    try:
        result = ssm_client.put_parameter(
            Name=parameter_name,
            Value=parameter_value,
            Type=parameter_type,
            Overwrite=True
        )
    except ClientError as e:
        raise stvParameterStoreError( e )
        return None
    return result['Version']

def get_parameter(parameter_name, with_decryption=False):
    """Get parameter details in AWS SSM

    :param parameter_name: Name of the parameter to fetch details from SSM
    :param with_decryption: return decrypted value for secured string params, ignored for String and StringList
    :return: Return parameter details if exist else None
    """
    ssm_client = boto3.client('ssm')

    try:
        result = ssm_client.get_parameter(
            Name=parameter_name,
            WithDecryption=with_decryption
        )
    except ClientError as e:
        raise stvParameterStoreError( e )
        return None
    return result


def get_parameters(parameter_names, with_decryption=False):
    """Get multiple parameter details in AWS SSM

    :param parameter_names: List of parameter names to fetch details from AWS SSM
    :param with_decryption: return decrypted value for secured string params, ignored for String and StringList
    :return: Return parameter details if exist else None
    """
    ssm_client = boto3.client('ssm')

    try:
        result = ssm_client.get_parameters(
            Names=parameter_names,
            WithDecryption=with_decryption
        )
    except ClientError as e:
        raise stvParameterStoreError( e )
        return None
    return result

def delete_parameter(parameter_name):
    """Delete parameter in AWS SSM

    :param parameter_name: Name of the parameter to delete from AWS SSM
    """
    ssm_client = boto3.client('ssm')

    try:
        ssm_client.delete_parameter(
            Name=parameter_name
        )
    except ClientError as e:
        raise stvParameterStoreError( e )


def delete_parameters(parameter_names):
    """Delete multiple parameters in AWS SSM

    :param parameter_names: List of parameter names to delete from AWS SSM
    """
    ssm_client = boto3.client('ssm')

    try:
        ssm_client.delete_parameters(
            Names=parameter_names
        )
    except ClientError as e:
        raise stvParameterStoreError( e )
